<template>
    <div>
        <Head>
            <Title>关于</Title>
        </Head>
        <h1>关于</h1>
        <h1>掘金创建于2015年。</h1>
        <div>回到首页</div>
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>