const o=""+new URL("logo.43113877.svg",import.meta.url).href,t=""+new URL("about.c9799bbd.svg",import.meta.url).href;export{o as _,t as a};
