import{s}from"./entry.65810f75.js";function t(e,u){return s()._useHead(e,u)}export{t as u};
