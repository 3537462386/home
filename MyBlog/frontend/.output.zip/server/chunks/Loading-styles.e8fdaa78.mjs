const Loading_vue_vue_type_style_index_0_scoped_e76f29f4_lang = '.loading[data-v-e76f29f4]{animation:spin-e76f29f4 2s ease infinite;border:5px solid #3cefff;height:5em;overflow:hidden;position:relative;width:5em}.loading[data-v-e76f29f4]:before{animation:fill-e76f29f4 2s linear infinite;background-color:rgba(61,239,255,.75);content:"";height:5em;left:-7.5px;position:absolute;top:-7.5px;transform:scaleY(1);transform-origin:center bottom;width:5em}@keyframes spin-e76f29f4{50%,to{transform:rotate(1turn)}}@keyframes fill-e76f29f4{25%,50%{transform:scaleY(0)}to{transform:scaleY(1)}}';

const LoadingStyles_e8fdaa78 = [Loading_vue_vue_type_style_index_0_scoped_e76f29f4_lang];

export { LoadingStyles_e8fdaa78 as default };
//# sourceMappingURL=Loading-styles.e8fdaa78.mjs.map
