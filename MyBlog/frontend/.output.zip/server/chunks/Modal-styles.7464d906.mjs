const Modal_vue_vue_type_style_index_0_scoped_3685d19e_lang = ".img[data-v-3685d19e]{align-items:center;border-radius:25px;box-shadow:22px 22px 30px rgba(0,0,0,.2),-22px -22px 30px #fff;display:flex;height:120px;justify-content:center;width:120px}.img[data-v-3685d19e],.img img[data-v-3685d19e]{transition:all .2s ease-out}.img img[data-v-3685d19e]{width:75px}.img[data-v-3685d19e]:hover{box-shadow:0 0 0 rgba(0,0,0,.2),0 0 0 hsla(0,0%,100%,.8),inset 22px 22px 30px rgba(0,0,0,.1),inset -22px -22px 30px #fff;cursor:pointer}.img:hover img[data-v-3685d19e]{width:70px}";

const ModalStyles_7464d906 = [Modal_vue_vue_type_style_index_0_scoped_3685d19e_lang];

export { ModalStyles_7464d906 as default };
//# sourceMappingURL=Modal-styles.7464d906.mjs.map
