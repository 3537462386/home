import { _ as _export_sfc, u as useRouter } from './server.mjs';
import { ref, reactive, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrInterpolate, ssrRenderList } from 'vue/server-renderer';
import { _ as _imports_0, a as _imports_1 } from './about.3e79d65e.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'destr';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import 'cookie-es';
import 'ohash';
import 'pinia-plugin-persistedstate';
import 'echarts';
import 'defu';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

const _imports_2 = "" + globalThis.__buildAssetsURL("me.02f49700.jpg");
const _sfc_main = {
  __name: "about",
  __ssrInlineRender: true,
  setup(__props) {
    useRouter();
    ref(new Date());
    const newPosts = ref([]);
    const song = reactive({
      url: "",
      lrc: "",
      name: ""
    });
    const posts = reactive({
      views: 0,
      likes: 0,
      posts: 0,
      comments: 0
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-4021b11b><div class="w-full myhead z-200 px-5 flex justify-between items-center" data-v-4021b11b><img${ssrRenderAttr("src", _imports_0)} class="cursor-pointer" data-v-4021b11b><audio${ssrRenderAttr("src", unref(song).url)} controls autoplay data-v-4021b11b></audio><img${ssrRenderAttr("src", _imports_1)} class="cursor-pointer" data-v-4021b11b></div><div class="w-full px-10 pt-20 flex" data-v-4021b11b><div class="w-55" data-v-4021b11b><img class="w-45 h-45 my-5 rounded-full"${ssrRenderAttr("src", _imports_2)} alt="\u5E05\u54E5\u5934\u50CF" data-v-4021b11b><h2 class="mb-5" data-v-4021b11b>Sakura</h2><div class="w-full flex items-center mb-3 scale-90" data-v-4021b11b><span class="iconfont icon-wenzhang1 mr-1" data-v-4021b11b></span><p class="mr-4" data-v-4021b11b>${ssrInterpolate(unref(posts).posts)}</p><span class="iconfont icon-aixin mr-1" data-v-4021b11b></span><p class="mr-4" data-v-4021b11b>${ssrInterpolate(unref(posts).likes)}</p><span class="iconfont icon-yanjing mr-1" data-v-4021b11b></span><p data-v-4021b11b>${ssrInterpolate(unref(posts).views)}</p></div><div class="mb-3 flex scale-90" data-v-4021b11b><span class="iconfont icon-dizi mr-1" data-v-4021b11b></span><p data-v-4021b11b>\u6C5F\u897F\u5357\u660C</p></div><div class="mb-3 flex scale-90" data-v-4021b11b><span class="iconfont icon-youjian mr-1" data-v-4021b11b></span><p data-v-4021b11b>luwen0710@qq.com</p></div><div class="flex scale-90" data-v-4021b11b><span class="iconfont icon-github mr-1" data-v-4021b11b></span><a href="https://github.com/3537462386" data-v-4021b11b>https://github.com/...</a></div></div><div class="w-300 p-10 rounded-1 border border-solid border-gray-300 ml-10 flex" data-v-4021b11b><div class="flex flex-col mr-20" data-v-4021b11b><h2 class="mb-3" data-v-4021b11b>Hi,\u6211\u662FSakura</h2><h2 class="mb-3" data-v-4021b11b>\u5173\u4E8E\u6211\uFF1A</h2><ul class="ml-8 mb-3" data-v-4021b11b><li data-v-4021b11b>\u524D\u7AEF\u7A0B\u5E8F\u5458</li><li data-v-4021b11b>\u5728\u6821\u5927\u56DB\u5B66\u751F</li><li data-v-4021b11b>\u6B63\u5728\u5BFB\u627E\u5DE5\u4F5C</li></ul><h2 class="mb-3" data-v-4021b11b>\u6700\u8FD1\u66F4\u65B0\uFF1A</h2><ul class="ml-8 mb-3" data-v-4021b11b><!--[-->`);
      ssrRenderList(unref(newPosts), (item) => {
        _push(`<li data-v-4021b11b><p class="text-blue-500 underline hover:cursor-pointer" data-v-4021b11b>${ssrInterpolate(item.title)}</p></li>`);
      });
      _push(`<!--]--></ul></div><div id="chart" class="w-100 h-60" data-v-4021b11b></div></div><div class="w-65" data-v-4021b11b></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/about.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const about = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-4021b11b"]]);

export { about as default };
//# sourceMappingURL=about.243aac8a.mjs.map
