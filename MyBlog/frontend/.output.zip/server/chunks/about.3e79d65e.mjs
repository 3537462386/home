const _imports_0 = "" + globalThis.__buildAssetsURL("logo.43113877.svg");
const _imports_1 = "" + globalThis.__buildAssetsURL("about.c9799bbd.svg");

export { _imports_0 as _, _imports_1 as a };
//# sourceMappingURL=about.3e79d65e.mjs.map
