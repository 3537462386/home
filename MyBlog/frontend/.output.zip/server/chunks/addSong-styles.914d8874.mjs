const addSong_vue_vue_type_style_index_0_lang = "";

const addSongStyles_914d8874 = [addSong_vue_vue_type_style_index_0_lang];

export { addSongStyles_914d8874 as default };
//# sourceMappingURL=addSong-styles.914d8874.mjs.map
