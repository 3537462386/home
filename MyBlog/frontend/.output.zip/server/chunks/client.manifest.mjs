const client_manifest = {
  "assets/iconfont/iconfont.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "iconfont.2ccf6fbb.woff",
    "src": "assets/iconfont/iconfont.woff"
  },
  "assets/iconfont/iconfont.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "iconfont.f54e1942.ttf",
    "src": "assets/iconfont/iconfont.ttf"
  },
  "assets/image/actions/about.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "about.c9799bbd.svg",
    "src": "assets/image/actions/about.svg"
  },
  "assets/image/logo/logo.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "logo.43113877.svg",
    "src": "assets/image/logo/logo.svg"
  },
  "assets/image/logo/me.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "me.02f49700.jpg",
    "src": "assets/image/logo/me.jpg"
  },
  "assets/image/phbg/1.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "1.b321b724.jpg",
    "src": "assets/image/phbg/1.jpg"
  },
  "assets/image/phbg/2.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "2.e01a1bdb.jpg",
    "src": "assets/image/phbg/2.jpg"
  },
  "assets/image/phbg/4.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "4.c53feae0.jpg",
    "src": "assets/image/phbg/4.jpg"
  },
  "assets/image/phbg/3.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "3.17d4bc3b.jpg",
    "src": "assets/image/phbg/3.jpg"
  },
  "assets/image/rocket.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "rocket.29767d6c.svg",
    "src": "assets/image/rocket.svg"
  },
  "assets/image/phbg/5.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "5.4d1801b1.jpg",
    "src": "assets/image/phbg/5.jpg"
  },
  "assets/image/pcbg/2.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "2.2fb2d4dd.jpg",
    "src": "assets/image/pcbg/2.jpg"
  },
  "assets/image/pcbg/5.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "5.ac038416.jpg",
    "src": "assets/image/pcbg/5.jpg"
  },
  "assets/image/pcbg/4.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "4.60c82fbf.jpg",
    "src": "assets/image/pcbg/4.jpg"
  },
  "assets/image/pcbg/1.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "1.0d299c40.jpg",
    "src": "assets/image/pcbg/1.jpg"
  },
  "assets/image/pcbg/3.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "3.342e13fb.jpg",
    "src": "assets/image/pcbg/3.jpg"
  },
  "assets/image/button/unaction.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "unaction.5f27c21f.svg",
    "src": "assets/image/button/unaction.svg"
  },
  "assets/image/actions/all.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "all.76c4c2ef.svg",
    "src": "assets/image/actions/all.svg"
  },
  "assets/image/actions/github.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "github.1a3306c4.svg",
    "src": "assets/image/actions/github.svg"
  },
  "assets/image/actions/home.svg": {
    "resourceType": "image",
    "mimeType": "image/svg+xml",
    "file": "home.65b5f818.svg",
    "src": "assets/image/actions/home.svg"
  },
  "../node_modules/nuxt/dist/app/entry.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "entry.65810f75.js",
    "src": "../node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "../virtual:nuxt:C:/Users/lw/Desktop/workspace/home/MyBlog/vite-nuxt3-app/.nuxt/error-component.mjs"
    ],
    "css": [
      "entry.9c6b3034.css"
    ],
    "assets": [
      "iconfont.2ccf6fbb.woff",
      "iconfont.f54e1942.ttf"
    ]
  },
  "entry.9c6b3034.css": {
    "file": "entry.9c6b3034.css",
    "resourceType": "style"
  },
  "iconfont.2ccf6fbb.woff": {
    "file": "iconfont.2ccf6fbb.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "iconfont.f54e1942.ttf": {
    "file": "iconfont.f54e1942.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "../virtual:nuxt:C:/Users/lw/Desktop/workspace/home/MyBlog/vite-nuxt3-app/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "file": "error-component.a273e46f.js",
    "src": "../virtual:nuxt:C:/Users/lw/Desktop/workspace/home/MyBlog/vite-nuxt3-app/.nuxt/error-component.mjs",
    "isDynamicEntry": true,
    "imports": [
      "../node_modules/nuxt/dist/app/entry.mjs"
    ],
    "dynamicImports": [
      "../node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "../node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ]
  },
  "pages/about.vue": {
    "resourceType": "script",
    "module": true,
    "file": "about.f8cf210b.js",
    "src": "pages/about.vue",
    "isDynamicEntry": true,
    "imports": [
      "../node_modules/nuxt/dist/app/entry.mjs",
      "_about.3e79d65e.js",
      "_index.57d7da95.js"
    ],
    "css": [],
    "assets": [
      "me.02f49700.jpg"
    ]
  },
  "about.7ddadf0f.css": {
    "file": "about.7ddadf0f.css",
    "resourceType": "style"
  },
  "me.02f49700.jpg": {
    "file": "me.02f49700.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "_about.3e79d65e.js": {
    "resourceType": "script",
    "module": true,
    "file": "about.3e79d65e.js",
    "assets": [
      "logo.43113877.svg",
      "about.c9799bbd.svg"
    ]
  },
  "logo.43113877.svg": {
    "file": "logo.43113877.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "about.c9799bbd.svg": {
    "file": "about.c9799bbd.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "_index.57d7da95.js": {
    "resourceType": "script",
    "module": true,
    "file": "index.57d7da95.js",
    "imports": [
      "../node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/addSong.vue": {
    "resourceType": "script",
    "module": true,
    "file": "addSong.fdd86721.js",
    "src": "pages/addSong.vue",
    "isDynamicEntry": true,
    "imports": [
      "../node_modules/nuxt/dist/app/entry.mjs",
      "_index.57d7da95.js"
    ],
    "css": []
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.114356d6.js",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "../node_modules/nuxt/dist/app/entry.mjs",
      "_indexState.c13635ac.js",
      "_about.3e79d65e.js",
      "_composables.cea79c3c.js",
      "_index.57d7da95.js"
    ],
    "css": [],
    "assets": [
      "unaction.5f27c21f.svg",
      "all.76c4c2ef.svg",
      "github.1a3306c4.svg",
      "home.65b5f818.svg",
      "rocket.29767d6c.svg",
      "1.0d299c40.jpg",
      "2.2fb2d4dd.jpg",
      "3.342e13fb.jpg",
      "4.60c82fbf.jpg",
      "5.ac038416.jpg",
      "1.b321b724.jpg",
      "2.e01a1bdb.jpg",
      "3.17d4bc3b.jpg",
      "4.c53feae0.jpg",
      "5.4d1801b1.jpg"
    ]
  },
  "index.403a4c53.css": {
    "file": "index.403a4c53.css",
    "resourceType": "style"
  },
  "Actions.0c94f109.css": {
    "file": "Actions.0c94f109.css",
    "resourceType": "style"
  },
  "unaction.5f27c21f.svg": {
    "file": "unaction.5f27c21f.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "all.76c4c2ef.svg": {
    "file": "all.76c4c2ef.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "github.1a3306c4.svg": {
    "file": "github.1a3306c4.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "home.65b5f818.svg": {
    "file": "home.65b5f818.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "rocket.29767d6c.svg": {
    "file": "rocket.29767d6c.svg",
    "resourceType": "image",
    "mimeType": "image/svg+xml"
  },
  "1.0d299c40.jpg": {
    "file": "1.0d299c40.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "2.2fb2d4dd.jpg": {
    "file": "2.2fb2d4dd.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "3.342e13fb.jpg": {
    "file": "3.342e13fb.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "4.60c82fbf.jpg": {
    "file": "4.60c82fbf.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "5.ac038416.jpg": {
    "file": "5.ac038416.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "1.b321b724.jpg": {
    "file": "1.b321b724.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "2.e01a1bdb.jpg": {
    "file": "2.e01a1bdb.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "3.17d4bc3b.jpg": {
    "file": "3.17d4bc3b.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "4.c53feae0.jpg": {
    "file": "4.c53feae0.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "5.4d1801b1.jpg": {
    "file": "5.4d1801b1.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "_composables.cea79c3c.js": {
    "resourceType": "script",
    "module": true,
    "file": "composables.cea79c3c.js",
    "imports": [
      "../node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "_indexState.c13635ac.js": {
    "resourceType": "script",
    "module": true,
    "file": "indexState.c13635ac.js",
    "imports": [
      "../node_modules/nuxt/dist/app/entry.mjs"
    ]
  },
  "pages/posts/[id]/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.48fd2eb0.js",
    "src": "pages/posts/[id]/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "_base.38812cfa.js",
      "../node_modules/nuxt/dist/app/entry.mjs",
      "_composables.cea79c3c.js",
      "_about.3e79d65e.js",
      "_indexState.c13635ac.js",
      "_index.57d7da95.js"
    ],
    "css": []
  },
  "index.88908362.css": {
    "file": "index.88908362.css",
    "resourceType": "style"
  },
  "_base.38812cfa.js": {
    "resourceType": "script",
    "module": true,
    "file": "base.38812cfa.js",
    "imports": [
      "../node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": [
      "base.0750e8f8.css"
    ]
  },
  "base.0750e8f8.css": {
    "file": "base.0750e8f8.css",
    "resourceType": "style"
  },
  "pages/posts/create.vue": {
    "resourceType": "script",
    "module": true,
    "file": "create.e9191465.js",
    "src": "pages/posts/create.vue",
    "isDynamicEntry": true,
    "imports": [
      "../node_modules/nuxt/dist/app/entry.mjs",
      "_index.57d7da95.js"
    ],
    "css": []
  },
  "pages/posts/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.b9fe2899.js",
    "src": "pages/posts/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "_base.38812cfa.js",
      "../node_modules/nuxt/dist/app/entry.mjs",
      "_about.3e79d65e.js",
      "_indexState.c13635ac.js",
      "_index.57d7da95.js"
    ],
    "css": []
  },
  "index.78f21062.css": {
    "file": "index.78f21062.css",
    "resourceType": "style"
  },
  "../node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "file": "error-404.5035f0f2.js",
    "src": "../node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
    "isDynamicEntry": true,
    "imports": [
      "../node_modules/nuxt/dist/app/entry.mjs",
      "_composables.cea79c3c.js"
    ],
    "css": []
  },
  "error-404.a6f724cc.css": {
    "file": "error-404.a6f724cc.css",
    "resourceType": "style"
  },
  "../node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "file": "error-500.24c1dd0a.js",
    "src": "../node_modules/@nuxt/ui-templates/dist/templates/error-500.vue",
    "isDynamicEntry": true,
    "imports": [
      "_composables.cea79c3c.js",
      "../node_modules/nuxt/dist/app/entry.mjs"
    ],
    "css": []
  },
  "error-500.d92554dd.css": {
    "file": "error-500.d92554dd.css",
    "resourceType": "style"
  },
  "pages/about.css": {
    "resourceType": "style",
    "file": "about.7ddadf0f.css",
    "src": "pages/about.css"
  },
  "pages/posts/index.css": {
    "resourceType": "style",
    "file": "index.78f21062.css",
    "src": "pages/posts/index.css"
  },
  "Actions.css": {
    "resourceType": "style",
    "file": "Actions.0c94f109.css",
    "src": "Actions.css"
  },
  "../node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.d92554dd.css",
    "src": "../node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.403a4c53.css",
    "src": "pages/index.css"
  },
  "base.css": {
    "resourceType": "style",
    "file": "base.0750e8f8.css",
    "src": "base.css"
  },
  "../node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.a6f724cc.css",
    "src": "../node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "pages/posts/[id]/index.css": {
    "resourceType": "style",
    "file": "index.88908362.css",
    "src": "pages/posts/[id]/index.css"
  },
  "../node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.9c6b3034.css",
    "src": "../node_modules/nuxt/dist/app/entry.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
