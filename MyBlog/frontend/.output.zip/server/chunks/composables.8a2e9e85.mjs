import { a as useNuxtApp } from './server.mjs';

function useHead(input, options) {
  return useNuxtApp()._useHead(input, options);
}

export { useHead as u };
//# sourceMappingURL=composables.8a2e9e85.mjs.map
