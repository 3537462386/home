const create_vue_vue_type_style_index_0_lang = "";

const createStyles_7d0e994f = [create_vue_vue_type_style_index_0_lang];

export { createStyles_7d0e994f as default };
//# sourceMappingURL=create-styles.7d0e994f.mjs.map
