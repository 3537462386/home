import { reactive, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = {
  __name: "create",
  __ssrInlineRender: true,
  setup(__props) {
    const state = reactive({
      Form: {
        title: "",
        content: "",
        sketch: "",
        imgs: ""
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "max-w-3xl mx-auto px-4 py-8" }, _attrs))}><h1 class="text-2xl font-bold mb-4">\u53D1\u5E03\u65B0\u6587\u7AE0</h1><div><label for="title" class="font-medium">\u6807\u9898</label><input type="text" id="title"${ssrRenderAttr("value", unref(state).Form.title)} class="block w-full border-gray-300 rounded-md shadow-sm py-2 px-3 mt-1" required></div><div><label for="sketch" class="font-medium">\u6982\u8FF0</label><input type="text" id="sketch"${ssrRenderAttr("value", unref(state).Form.sketch)} class="block w-full border-gray-300 rounded-md shadow-sm py-2 px-3 mt-1" required></div><div><label for="content" class="font-medium">\u5185\u5BB9</label><textarea id="content" class="block w-full border-gray-300 rounded-md shadow-sm py-2 px-3 mt-1" rows="8" required>${ssrInterpolate(unref(state).Form.content)}</textarea></div><div><label for="imgs" class="font-medium">\u56FE\u7247</label><input type="text" id="imgs"${ssrRenderAttr("value", unref(state).Form.imgs)} class="block w-full border-gray-300 rounded-md shadow-sm py-2 px-3 mt-1" required></div><div class="flex justify-end"><button class="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded">\u53D1\u5E03</button></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/posts/create.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=create.c42e3247.mjs.map
