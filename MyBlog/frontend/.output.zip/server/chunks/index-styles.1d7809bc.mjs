const index_vue_vue_type_style_index_0_scoped_a0679429_lang = ".myhead[data-v-a0679429]{background-color:#f1f1f1;border-bottom:1px solid #ccc;box-shadow:inset 0 -1px 1px rgba(0,0,0,.1);height:0;margin:0;overflow:hidden;position:fixed;right:0;top:0;transition:all .5s ease-in-out}.myhead.show[data-v-a0679429]{height:40px}";

const indexStyles_1d7809bc = [index_vue_vue_type_style_index_0_scoped_a0679429_lang];

export { indexStyles_1d7809bc as default };
//# sourceMappingURL=index-styles.1d7809bc.mjs.map
