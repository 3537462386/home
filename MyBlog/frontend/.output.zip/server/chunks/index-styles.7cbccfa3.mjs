const index_vue_vue_type_style_index_0_scoped_593909d1_lang = ".midLine[data-v-593909d1]{border-left:1px solid #e5e7eb;bottom:0;height:100%;left:50%;position:absolute;top:0;z-index:-100}.content[data-v-593909d1]{-webkit-box-orient:vertical;-webkit-line-clamp:3;display:-webkit-box;overflow:hidden;text-overflow:ellipsis}#rocket[data-v-593909d1]{height:40px;position:fixed;width:40px}.light-theme[data-v-593909d1]{transition:border .5s ease-in-out;transition:background-color .5s ease-in-out;transition:color .5s ease-in-out}.light-theme .textbox[data-v-593909d1]{border:1px solid #e5e7eb;transition:border .5s ease-in-out}.dark-theme[data-v-593909d1]{background-color:#000;color:#fff;transition:background-color .5s ease-in-out;transition:color .5s ease-in-out}.dark-theme .textbox[data-v-593909d1]{border:1px solid #57595c;transition:border .5s ease-in-out}";

const indexStyles_7cbccfa3 = [index_vue_vue_type_style_index_0_scoped_593909d1_lang];

export { indexStyles_7cbccfa3 as default };
//# sourceMappingURL=index-styles.7cbccfa3.mjs.map
