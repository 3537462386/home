const index_vue_vue_type_style_index_0_scoped_8ce9a677_lang = ".textRed[data-v-8ce9a677]{color:red}.comments ul[data-v-8ce9a677]{list-style:none;overflow:hidden;transition:.6s}.light-theme[data-v-8ce9a677]{background-color:#fff;color:#000;transition:background-color .5s ease-in-out;transition:color .5s ease-in-out}.dark-theme[data-v-8ce9a677],.dark-theme input[data-v-8ce9a677],.dark-theme textarea[data-v-8ce9a677]{background-color:#000;color:#fff;transition:background-color .5s ease-in-out;transition:color .5s ease-in-out}";

const indexStyles_faca09a3 = [index_vue_vue_type_style_index_0_scoped_8ce9a677_lang];

export { indexStyles_faca09a3 as default };
//# sourceMappingURL=index-styles.faca09a3.mjs.map
