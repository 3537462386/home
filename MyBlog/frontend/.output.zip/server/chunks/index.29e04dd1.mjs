import { ref, defineComponent, openBlock, createBlock, resolveDynamicComponent, mergeProps, unref, withCtx, createElementBlock, Fragment, renderSlot, normalizeClass, createCommentVNode, provide, reactive, toRef, computed, inject, useSlots, Text, useSSRContext, createTextVNode, watch, getCurrentInstance, onServerPrefetch } from 'vue';
import { b as buildProp, a as buildProps, i as iconPropType, d as definePropType, u as useNamespace, E as ElIcon, w as withInstall, c as withNoopInstall, _ as _export_sfc$1 } from './base.21f488d5.mjs';
import { Loading } from '@element-plus/icons-vue';
import { TinyColor } from '@ctrl/tinycolor';
import { _ as _export_sfc, b as useRoute, u as useRouter, a as useNuxtApp, c as createError } from './server.mjs';
import { u as useHead } from './composables.8a2e9e85.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderStyle, ssrRenderAttr, ssrRenderClass, ssrRenderList } from 'vue/server-renderer';
import { _ as _imports_0, a as _imports_1 } from './about.3e79d65e.mjs';
import { u as useIndexState } from './indexState.373c6501.mjs';
import { hash } from 'ohash';
import 'lodash-unified';
import '@vue/shared';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'destr';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import 'cookie-es';
import 'pinia-plugin-persistedstate';
import 'echarts';
import 'defu';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

const getDefault = () => null;
function useAsyncData(...args) {
  var _a, _b, _c, _d, _e, _f, _g;
  const autoKey = typeof args[args.length - 1] === "string" ? args.pop() : void 0;
  if (typeof args[0] !== "string") {
    args.unshift(autoKey);
  }
  let [key, handler, options = {}] = args;
  if (typeof key !== "string") {
    throw new TypeError("[nuxt] [asyncData] key must be a string.");
  }
  if (typeof handler !== "function") {
    throw new TypeError("[nuxt] [asyncData] handler must be a function.");
  }
  options.server = (_a = options.server) != null ? _a : true;
  options.default = (_b = options.default) != null ? _b : getDefault;
  options.lazy = (_c = options.lazy) != null ? _c : false;
  options.immediate = (_d = options.immediate) != null ? _d : true;
  const nuxt = useNuxtApp();
  const getCachedData = () => nuxt.isHydrating ? nuxt.payload.data[key] : nuxt.static.data[key];
  const hasCachedData = () => getCachedData() !== void 0;
  if (!nuxt._asyncData[key]) {
    nuxt._asyncData[key] = {
      data: ref((_g = (_f = getCachedData()) != null ? _f : (_e = options.default) == null ? void 0 : _e.call(options)) != null ? _g : null),
      pending: ref(!hasCachedData()),
      error: ref(nuxt.payload._errors[key] ? createError(nuxt.payload._errors[key]) : null)
    };
  }
  const asyncData = { ...nuxt._asyncData[key] };
  asyncData.refresh = asyncData.execute = (opts = {}) => {
    if (nuxt._asyncDataPromises[key]) {
      if (opts.dedupe === false) {
        return nuxt._asyncDataPromises[key];
      }
      nuxt._asyncDataPromises[key].cancelled = true;
    }
    if (opts._initial && hasCachedData()) {
      return getCachedData();
    }
    asyncData.pending.value = true;
    const promise = new Promise(
      (resolve, reject) => {
        try {
          resolve(handler(nuxt));
        } catch (err) {
          reject(err);
        }
      }
    ).then((result) => {
      if (promise.cancelled) {
        return nuxt._asyncDataPromises[key];
      }
      if (options.transform) {
        result = options.transform(result);
      }
      if (options.pick) {
        result = pick(result, options.pick);
      }
      asyncData.data.value = result;
      asyncData.error.value = null;
    }).catch((error) => {
      var _a2, _b2;
      if (promise.cancelled) {
        return nuxt._asyncDataPromises[key];
      }
      asyncData.error.value = error;
      asyncData.data.value = unref((_b2 = (_a2 = options.default) == null ? void 0 : _a2.call(options)) != null ? _b2 : null);
    }).finally(() => {
      if (promise.cancelled) {
        return;
      }
      asyncData.pending.value = false;
      nuxt.payload.data[key] = asyncData.data.value;
      if (asyncData.error.value) {
        nuxt.payload._errors[key] = createError(asyncData.error.value);
      }
      delete nuxt._asyncDataPromises[key];
    });
    nuxt._asyncDataPromises[key] = promise;
    return nuxt._asyncDataPromises[key];
  };
  const initialFetch = () => asyncData.refresh({ _initial: true });
  const fetchOnServer = options.server !== false && nuxt.payload.serverRendered;
  if (fetchOnServer && options.immediate) {
    const promise = initialFetch();
    onServerPrefetch(() => promise);
  }
  const asyncDataPromise = Promise.resolve(nuxt._asyncDataPromises[key]).then(() => asyncData);
  Object.assign(asyncDataPromise, asyncData);
  return asyncDataPromise;
}
function pick(obj, keys) {
  const newObj = {};
  for (const key of keys) {
    newObj[key] = obj[key];
  }
  return newObj;
}
function useFetch(request, arg1, arg2) {
  const [opts = {}, autoKey] = typeof arg1 === "string" ? [{}, arg1] : [arg1, arg2];
  const _key = opts.key || hash([autoKey, unref(opts.baseURL), typeof request === "string" ? request : "", unref(opts.params)]);
  if (!_key || typeof _key !== "string") {
    throw new TypeError("[nuxt] [useFetch] key must be a string: " + _key);
  }
  if (!request) {
    throw new Error("[nuxt] [useFetch] request is missing.");
  }
  const key = _key === autoKey ? "$f" + _key : _key;
  const _request = computed(() => {
    let r = request;
    if (typeof r === "function") {
      r = r();
    }
    return unref(r);
  });
  const {
    server,
    lazy,
    default: defaultFn,
    transform,
    pick: pick2,
    watch: watch2,
    immediate,
    ...fetchOptions
  } = opts;
  const _fetchOptions = reactive({
    ...fetchOptions,
    cache: typeof opts.cache === "boolean" ? void 0 : opts.cache
  });
  const _asyncDataOptions = {
    server,
    lazy,
    default: defaultFn,
    transform,
    pick: pick2,
    immediate,
    watch: [
      _fetchOptions,
      _request,
      ...watch2 || []
    ]
  };
  let controller;
  const asyncData = useAsyncData(key, () => {
    var _a;
    (_a = controller == null ? void 0 : controller.abort) == null ? void 0 : _a.call(controller);
    controller = typeof AbortController !== "undefined" ? new AbortController() : {};
    return $fetch(_request.value, { signal: controller.signal, ..._fetchOptions });
  }, _asyncDataOptions);
  return asyncData;
}
const componentSizes = ["", "default", "small", "large"];
const useDeprecated = ({ from, replacement, scope, version, ref: ref2, type = "API" }, condition) => {
  watch(() => unref(condition), (val) => {
  }, {
    immediate: true
  });
};
const useProp = (name) => {
  const vm = getCurrentInstance();
  return computed(() => {
    var _a, _b;
    return (_b = (_a = vm == null ? void 0 : vm.proxy) == null ? void 0 : _a.$props) == null ? void 0 : _b[name];
  });
};
const useSizeProp = buildProp({
  type: String,
  values: componentSizes,
  required: false
});
const SIZE_INJECTION_KEY = Symbol("size");
const useGlobalSize = () => {
  const injectedSize = inject(SIZE_INJECTION_KEY, {});
  return computed(() => {
    return unref(injectedSize.size) || "";
  });
};
const configProviderContextKey = Symbol();
const globalConfig = ref();
function useGlobalConfig(key, defaultValue = void 0) {
  const config = getCurrentInstance() ? inject(configProviderContextKey, globalConfig) : globalConfig;
  if (key) {
    return computed(() => {
      var _a, _b;
      return (_b = (_a = config.value) == null ? void 0 : _a[key]) != null ? _b : defaultValue;
    });
  } else {
    return config;
  }
}
const formContextKey = Symbol("formContextKey");
const formItemContextKey = Symbol("formItemContextKey");
const useFormSize = (fallback, ignore = {}) => {
  const emptyRef = ref(void 0);
  const size = ignore.prop ? emptyRef : useProp("size");
  const globalConfig2 = ignore.global ? emptyRef : useGlobalSize();
  const form = ignore.form ? { size: void 0 } : inject(formContextKey, void 0);
  const formItem = ignore.formItem ? { size: void 0 } : inject(formItemContextKey, void 0);
  return computed(() => size.value || unref(fallback) || (formItem == null ? void 0 : formItem.size) || (form == null ? void 0 : form.size) || globalConfig2.value || "");
};
const useFormDisabled = (fallback) => {
  const disabled = useProp("disabled");
  const form = inject(formContextKey, void 0);
  return computed(() => disabled.value || unref(fallback) || (form == null ? void 0 : form.disabled) || false);
};
const useFormItem = () => {
  const form = inject(formContextKey, void 0);
  const formItem = inject(formItemContextKey, void 0);
  return {
    form,
    formItem
  };
};
const buttonGroupContextKey = Symbol("buttonGroupContextKey");
const useButton = (props, emit) => {
  useDeprecated({
    from: "type.text",
    replacement: "link",
    version: "3.0.0",
    scope: "props",
    ref: "https://element-plus.org/en-US/component/button.html#button-attributes"
  }, computed(() => props.type === "text"));
  const buttonGroupContext = inject(buttonGroupContextKey, void 0);
  const globalConfig2 = useGlobalConfig("button");
  const { form } = useFormItem();
  const _size = useFormSize(computed(() => buttonGroupContext == null ? void 0 : buttonGroupContext.size));
  const _disabled = useFormDisabled();
  const _ref = ref();
  const slots = useSlots();
  const _type = computed(() => props.type || (buttonGroupContext == null ? void 0 : buttonGroupContext.type) || "");
  const autoInsertSpace = computed(() => {
    var _a, _b, _c;
    return (_c = (_b = props.autoInsertSpace) != null ? _b : (_a = globalConfig2.value) == null ? void 0 : _a.autoInsertSpace) != null ? _c : false;
  });
  const _props = computed(() => {
    if (props.tag === "button") {
      return {
        ariaDisabled: _disabled.value || props.loading,
        disabled: _disabled.value || props.loading,
        autofocus: props.autofocus,
        type: props.nativeType
      };
    }
    return {};
  });
  const shouldAddSpace = computed(() => {
    var _a;
    const defaultSlot = (_a = slots.default) == null ? void 0 : _a.call(slots);
    if (autoInsertSpace.value && (defaultSlot == null ? void 0 : defaultSlot.length) === 1) {
      const slot = defaultSlot[0];
      if ((slot == null ? void 0 : slot.type) === Text) {
        const text = slot.children;
        return /^\p{Unified_Ideograph}{2}$/u.test(text.trim());
      }
    }
    return false;
  });
  const handleClick = (evt) => {
    if (props.nativeType === "reset") {
      form == null ? void 0 : form.resetFields();
    }
    emit("click", evt);
  };
  return {
    _disabled,
    _size,
    _type,
    _ref,
    _props,
    shouldAddSpace,
    handleClick
  };
};
const buttonTypes = [
  "default",
  "primary",
  "success",
  "warning",
  "info",
  "danger",
  "text",
  ""
];
const buttonNativeTypes = ["button", "submit", "reset"];
const buttonProps = buildProps({
  size: useSizeProp,
  disabled: Boolean,
  type: {
    type: String,
    values: buttonTypes,
    default: ""
  },
  icon: {
    type: iconPropType
  },
  nativeType: {
    type: String,
    values: buttonNativeTypes,
    default: "button"
  },
  loading: Boolean,
  loadingIcon: {
    type: iconPropType,
    default: () => Loading
  },
  plain: Boolean,
  text: Boolean,
  link: Boolean,
  bg: Boolean,
  autofocus: Boolean,
  round: Boolean,
  circle: Boolean,
  color: String,
  dark: Boolean,
  autoInsertSpace: {
    type: Boolean,
    default: void 0
  },
  tag: {
    type: definePropType([String, Object]),
    default: "button"
  }
});
const buttonEmits = {
  click: (evt) => evt instanceof MouseEvent
};
function darken(color, amount = 20) {
  return color.mix("#141414", amount).toString();
}
function useButtonCustomStyle(props) {
  const _disabled = useFormDisabled();
  const ns = useNamespace("button");
  return computed(() => {
    let styles = {};
    const buttonColor = props.color;
    if (buttonColor) {
      const color = new TinyColor(buttonColor);
      const activeBgColor = props.dark ? color.tint(20).toString() : darken(color, 20);
      if (props.plain) {
        styles = ns.cssVarBlock({
          "bg-color": props.dark ? darken(color, 90) : color.tint(90).toString(),
          "text-color": buttonColor,
          "border-color": props.dark ? darken(color, 50) : color.tint(50).toString(),
          "hover-text-color": `var(${ns.cssVarName("color-white")})`,
          "hover-bg-color": buttonColor,
          "hover-border-color": buttonColor,
          "active-bg-color": activeBgColor,
          "active-text-color": `var(${ns.cssVarName("color-white")})`,
          "active-border-color": activeBgColor
        });
        if (_disabled.value) {
          styles[ns.cssVarBlockName("disabled-bg-color")] = props.dark ? darken(color, 90) : color.tint(90).toString();
          styles[ns.cssVarBlockName("disabled-text-color")] = props.dark ? darken(color, 50) : color.tint(50).toString();
          styles[ns.cssVarBlockName("disabled-border-color")] = props.dark ? darken(color, 80) : color.tint(80).toString();
        }
      } else {
        const hoverBgColor = props.dark ? darken(color, 30) : color.tint(30).toString();
        const textColor = color.isDark() ? `var(${ns.cssVarName("color-white")})` : `var(${ns.cssVarName("color-black")})`;
        styles = ns.cssVarBlock({
          "bg-color": buttonColor,
          "text-color": textColor,
          "border-color": buttonColor,
          "hover-bg-color": hoverBgColor,
          "hover-text-color": textColor,
          "hover-border-color": hoverBgColor,
          "active-bg-color": activeBgColor,
          "active-border-color": activeBgColor
        });
        if (_disabled.value) {
          const disabledButtonColor = props.dark ? darken(color, 50) : color.tint(50).toString();
          styles[ns.cssVarBlockName("disabled-bg-color")] = disabledButtonColor;
          styles[ns.cssVarBlockName("disabled-text-color")] = props.dark ? "rgba(255, 255, 255, 0.5)" : `var(${ns.cssVarName("color-white")})`;
          styles[ns.cssVarBlockName("disabled-border-color")] = disabledButtonColor;
        }
      }
    }
    return styles;
  });
}
const __default__$1 = defineComponent({
  name: "ElButton"
});
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  ...__default__$1,
  props: buttonProps,
  emits: buttonEmits,
  setup(__props, { expose, emit }) {
    const props = __props;
    const buttonStyle = useButtonCustomStyle(props);
    const ns = useNamespace("button");
    const { _ref, _size, _type, _disabled, _props, shouldAddSpace, handleClick } = useButton(props, emit);
    expose({
      ref: _ref,
      size: _size,
      type: _type,
      disabled: _disabled,
      shouldAddSpace
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(resolveDynamicComponent(_ctx.tag), mergeProps({
        ref_key: "_ref",
        ref: _ref
      }, unref(_props), {
        class: [
          unref(ns).b(),
          unref(ns).m(unref(_type)),
          unref(ns).m(unref(_size)),
          unref(ns).is("disabled", unref(_disabled)),
          unref(ns).is("loading", _ctx.loading),
          unref(ns).is("plain", _ctx.plain),
          unref(ns).is("round", _ctx.round),
          unref(ns).is("circle", _ctx.circle),
          unref(ns).is("text", _ctx.text),
          unref(ns).is("link", _ctx.link),
          unref(ns).is("has-bg", _ctx.bg)
        ],
        style: unref(buttonStyle),
        onClick: unref(handleClick)
      }), {
        default: withCtx(() => [
          _ctx.loading ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
            _ctx.$slots.loading ? renderSlot(_ctx.$slots, "loading", { key: 0 }) : (openBlock(), createBlock(unref(ElIcon), {
              key: 1,
              class: normalizeClass(unref(ns).is("loading"))
            }, {
              default: withCtx(() => [
                (openBlock(), createBlock(resolveDynamicComponent(_ctx.loadingIcon)))
              ]),
              _: 1
            }, 8, ["class"]))
          ], 64)) : _ctx.icon || _ctx.$slots.icon ? (openBlock(), createBlock(unref(ElIcon), { key: 1 }, {
            default: withCtx(() => [
              _ctx.icon ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.icon), { key: 0 })) : renderSlot(_ctx.$slots, "icon", { key: 1 })
            ]),
            _: 3
          })) : createCommentVNode("v-if", true),
          _ctx.$slots.default ? (openBlock(), createElementBlock("span", {
            key: 2,
            class: normalizeClass({ [unref(ns).em("text", "expand")]: unref(shouldAddSpace) })
          }, [
            renderSlot(_ctx.$slots, "default")
          ], 2)) : createCommentVNode("v-if", true)
        ]),
        _: 3
      }, 16, ["class", "style", "onClick"]);
    };
  }
});
var Button = /* @__PURE__ */ _export_sfc$1(_sfc_main$3, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/button/src/button.vue"]]);
const buttonGroupProps = {
  size: buttonProps.size,
  type: buttonProps.type
};
const __default__ = defineComponent({
  name: "ElButtonGroup"
});
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  ...__default__,
  props: buttonGroupProps,
  setup(__props) {
    const props = __props;
    provide(buttonGroupContextKey, reactive({
      size: toRef(props, "size"),
      type: toRef(props, "type")
    }));
    const ns = useNamespace("button");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(`${unref(ns).b("group")}`)
      }, [
        renderSlot(_ctx.$slots, "default")
      ], 2);
    };
  }
});
var ButtonGroup = /* @__PURE__ */ _export_sfc$1(_sfc_main$2, [["__file", "/home/runner/work/element-plus/element-plus/packages/components/button/src/button-group.vue"]]);
const ElButton = withInstall(Button, {
  ButtonGroup
});
withNoopInstall(ButtonGroup);
const BASE_URL = "http://124.71.113.71:3000";
class HttpRequest {
  request(url, method, data, options) {
    return new Promise((resolve, reject) => {
      const newOptions = {
        baseURL: BASE_URL,
        method,
        ...options
      };
      if (method === "GET" || method === "DELETE") {
        newOptions.params = data;
      }
      if (method === "POST" || method === "PUT") {
        newOptions.body = data;
      }
      useFetch(url, newOptions, "$itdt56S9V1").then((res) => {
        resolve(res);
      }).catch((error) => {
        reject(error);
      });
    });
  }
  get(url, params, options) {
    return this.request(url, "GET", params, options);
  }
  post(url, data, options) {
    return this.request(url, "POST", data, options);
  }
  Put(url, data, options) {
    return this.request(url, "PUT", data, options);
  }
  Delete(url, params, options) {
    return this.request(url, "DELETE", params, options);
  }
}
const httpRequest = new HttpRequest();
const GetCommentByPost = (data) => {
  return httpRequest.post("/api/comment/getCommentByPost", data);
};
const AddComment = (data) => {
  return httpRequest.post("/api/comment/addComment", data);
};
const _sfc_main$1 = {
  __name: "Head",
  __ssrInlineRender: true,
  setup(__props) {
    const indexState = useIndexState();
    useRoute();
    useRouter();
    const state = reactive({
      showButton: true,
      lastScrollPosition: 0,
      isLiked: false,
      post: []
    });
    const song = reactive({
      url: "",
      lrc: "",
      name: ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-858e8261><div class="${ssrRenderClass([{
        "dark-theme": unref(indexState).theme,
        "light-theme": !unref(indexState).theme,
        "show": unref(state).showButton
      }, "w-full myhead z-200 px-5 flex justify-between items-center"])}" data-v-858e8261><img${ssrRenderAttr("src", _imports_0)} class="cursor-pointer" data-v-858e8261><audio${ssrRenderAttr("src", unref(song).url)} controls autoplay data-v-858e8261></audio><img${ssrRenderAttr("src", _imports_1)} class="cursor-pointer" data-v-858e8261></div><div class="${ssrRenderClass([{
        "dark-theme": unref(indexState).theme,
        "light-theme": !unref(indexState).theme,
        "show": !unref(state).showButton
      }, "w-full myfoot z-200 px-5 flex justify-around items-center"])}" data-v-858e8261><div class="lrc" data-v-858e8261><ul data-v-858e8261><!--[-->`);
      ssrRenderList(unref(song).lrc, (item) => {
        _push(`<li data-v-858e8261>${ssrInterpolate(item.words)}</li>`);
      });
      _push(`<!--]--><li data-v-858e8261></li></ul></div><div class="button flex justify-center items-center cursor-pointer" data-v-858e8261><span class="iconfont icon-yanjing" data-v-858e8261></span><p data-v-858e8261>${ssrInterpolate(unref(state).post.views + 1)}</p><span class="iconfont icon-xinxi" data-v-858e8261></span><p data-v-858e8261>${ssrInterpolate(unref(state).post.comments ? unref(state).post.comments.length : "0")}</p><span class="iconfont icon-aixin" style="${ssrRenderStyle(!unref(state).isLiked ? null : { display: "none" })}" data-v-858e8261></span><span class="iconfont icon-aixin1" style="${ssrRenderStyle([
        { "color": "rgb(230, 96, 96)" },
        unref(state).isLiked ? null : { display: "none" }
      ])}" data-v-858e8261></span><p data-v-858e8261>${ssrInterpolate(unref(state).post.likes)}</p><span class="iconfont icon-taiyangtianqi" style="${ssrRenderStyle(!unref(indexState).theme ? null : { display: "none" })}" data-v-858e8261></span><span class="iconfont icon-yueguang" style="${ssrRenderStyle(unref(indexState).theme ? null : { display: "none" })}" data-v-858e8261></span><span class="iconfont icon-huidaodingbu" data-v-858e8261></span></div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Head.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const Head = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-858e8261"]]);
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const indexState = useIndexState();
    const route = useRoute();
    const state = reactive({
      post: [],
      comments: [],
      comment: {
        name: "",
        email: "",
        content: "",
        postId: route.params.id
      },
      inputtext: "~\u8BA4\u771F\u548C\u7528\u5FC3\u662F\u4E00\u79CD\u6001\u5EA6, \u611F\u8C22\u652F\u6301~",
      isRed: false
    });
    useHead({
      title: "\u6587\u7AE0"
    });
    const submitComment = async () => {
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (state.comment.name === "") {
        state.inputtext = "\u60A8\u7684\u540D\u5B57\u662F\u7B2C\u4E00\u5370\u8C61\u54E6\uFF5E";
        state.isRed = true;
        return;
      } else if (!emailPattern.test(state.comment.email)) {
        state.inputtext = "\u8BF7\u8F93\u5165\u6B63\u786E\u7684\u90AE\u7BB1\uFF0C\u671F\u5F85\u56DE\u4FE1\uFF5E";
        state.isRed = true;
        return;
      } else if (state.comment.content === "") {
        state.inputtext = "\u5077\u5077\u544A\u8BC9\u6211\uFF0C\u4F60\u4F5C\u6587\u662F\u4E0D\u662F0\u5206\uFF5E";
        state.isRed = true;
        return;
      } else {
        state.isRed = false;
        state.inputtext = "~\u8BA4\u771F\u548C\u7528\u5FC3\u662F\u4E00\u79CD\u6001\u5EA6, \u611F\u8C22\u652F\u6301~";
        const params = route.params;
        await AddComment(state.comment);
        const comment = await GetCommentByPost({ _id: params.id });
        state.comments = comment.data.value.data;
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_el_button = ElButton;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["w-screen", unref(indexState).theme ? "dark-theme" : "light-theme"]
      }, _attrs))} data-v-8ce9a677>`);
      _push(ssrRenderComponent(Head, null, null, _parent));
      _push(`<div class="post px-10 py-30 flex flex-col justify-center items-center w-full md:px-10vw lg:px-22vw" data-v-8ce9a677><h1 class="" data-v-8ce9a677>${ssrInterpolate(unref(state).post.title)}</h1><p class="py-10" style="${ssrRenderStyle({ "white-space": "pre-wrap", "line-height": "2" })}" data-v-8ce9a677>${ssrInterpolate(unref(state).post.content)}</p><div class="w-full flex flex-col items-center justify-center h-70 rounded p-5" style="${ssrRenderStyle({ "border": "1px solid rgb(158, 150, 150,0.3)", "border-radius": "4px" })}" data-v-8ce9a677><div class="flex items-center justify-center w-full mx-10" data-v-8ce9a677><input type="text" class="w-1/2 h-8 mr-2 border-none opacity-50 focus:outline-none focus:opacity-100"${ssrRenderAttr("value", unref(state).comment.name)} style="${ssrRenderStyle({ "border-bottom": "1px dashed  rgb(90, 74, 74)" })}" placeholder="Name" data-v-8ce9a677><input type="email" class="w-1/2 h-8 ml-2 border-none opacity-50 focus:outline-none focus:opacity-100"${ssrRenderAttr("value", unref(state).comment.email)} style="${ssrRenderStyle({ "border-bottom": "1px dashed  rgb(80, 69, 69)" })}" placeholder="Email" data-v-8ce9a677></div><div class="w-full mx-10 m-3" data-v-8ce9a677><textarea type="email" class="w-full p-3 h-40 border-none opacity-50 focus:outline-none focus:opacity-100" style="${ssrRenderStyle({ "border": "1px dashed  rgb(71, 62, 62)", "border-radius": "4px" })}" placeholder="What do you want to say?" data-v-8ce9a677>${ssrInterpolate(unref(state).comment.content)}</textarea></div><div class="w-full flex items-center" data-v-8ce9a677>`);
      _push(ssrRenderComponent(_component_el_button, {
        onClick: submitComment,
        class: "mr-4"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Submit`);
          } else {
            return [
              createTextVNode("Submit")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<span class="iconfont icon-icon-hongcha mr-2" style="${ssrRenderStyle([
        { "color": "red", "font-size": "10px" },
        unref(state).isRed ? null : { display: "none" }
      ])}" data-v-8ce9a677></span><div class="${ssrRenderClass([{ "textRed": unref(state).isRed }, "opacity-50"])}" data-v-8ce9a677>${ssrInterpolate(unref(state).inputtext)}</div></div></div><div class="comments w-full my-10" data-v-8ce9a677><p class="" data-v-8ce9a677>comments\xA0(${ssrInterpolate(unref(state).post.comments ? unref(state).post.comments.length : 0)})</p><ul class="w-full" data-v-8ce9a677><!--[-->`);
      ssrRenderList(unref(state).comments, (item) => {
        _push(`<li class="w-full m-5 px-6 flex items-center justify-between" data-v-8ce9a677><div class="flex" data-v-8ce9a677><p class="" style="${ssrRenderStyle({ "color": "red" })}" data-v-8ce9a677>${ssrInterpolate(item.name)}:</p><p class="mx-5" data-v-8ce9a677>${ssrInterpolate(item.content)}</p></div><p class="opacity-30" style="${ssrRenderStyle({ "font-size": "10px" })}" data-v-8ce9a677>${ssrInterpolate(item.createdAt.split("T")[0])}</p></li>`);
      });
      _push(`<!--]--></ul></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/posts/[id]/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-8ce9a677"]]);

export { index as default };
//# sourceMappingURL=index.29e04dd1.mjs.map
