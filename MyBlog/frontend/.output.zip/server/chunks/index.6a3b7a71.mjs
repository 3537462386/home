import { ref, mergeProps, unref, useSSRContext, reactive, watch } from 'vue';
import { ssrRenderAttrs, ssrRenderStyle, ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderClass, ssrRenderList } from 'vue/server-renderer';
import { _ as _export_sfc, u as useRouter } from './server.mjs';
import { u as useIndexState } from './indexState.373c6501.mjs';
import { _ as _imports_0$1, a as _imports_1$2 } from './about.3e79d65e.mjs';
import { u as useHead } from './composables.8a2e9e85.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'destr';
import 'ufo';
import 'h3';
import '@unhead/vue';
import '@unhead/dom';
import 'vue-router';
import 'cookie-es';
import 'ohash';
import 'pinia-plugin-persistedstate';
import 'echarts';
import 'defu';
import './node-server.mjs';
import 'node-fetch-native/polyfill';
import 'http';
import 'https';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';

const _sfc_main$4 = {
  __name: "Actions",
  __ssrInlineRender: true,
  setup(__props) {
    const indexState = useIndexState();
    const showButton = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["mybutton z-200", { "show": unref(showButton) }]
      }, _attrs))} data-v-22b5167d><span class="iconfont icon-taiyangtianqi" style="${ssrRenderStyle(!unref(indexState).theme ? null : { display: "none" })}" data-v-22b5167d></span><span class="iconfont icon-yueguang" style="${ssrRenderStyle(unref(indexState).theme ? null : { display: "none" })}" data-v-22b5167d></span><span class="iconfont icon-huidaodingbu" data-v-22b5167d></span></div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Actions.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-22b5167d"]]);

const _sfc_main$3 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({
    class: "fixed w-screen h-screen z-500 flex flex-col justify-center items-center",
    style: { "background-color": "white" }
  }, _attrs))} data-v-e76f29f4><div class="loading" data-v-e76f29f4></div><h1 data-v-e76f29f4>Sakura\u7684\u535A\u5BA2</h1><h2 data-v-e76f29f4>Loading...</h2></div>`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Loading.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-e76f29f4"]]);
const _sfc_main$2 = {
  __name: "LoadMore",
  __ssrInlineRender: true,
  setup(__props) {
    const Loading = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "container" }, _attrs))} data-v-3317a61c><button class="btn" style="${ssrRenderStyle(!unref(Loading) ? null : { display: "none" })}" data-v-3317a61c> \u52A0\u8F7D\u66F4\u591A </button><div class="dots" style="${ssrRenderStyle(unref(Loading) ? null : { display: "none" })}" data-v-3317a61c><div class="bg-red-500" data-v-3317a61c></div><div class="bg-emerald-500" data-v-3317a61c></div><div class="bg-yellow-400" data-v-3317a61c></div><div class="bg-indigo-500" data-v-3317a61c></div></div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/LoadMore.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-3317a61c"]]);
const _imports_0 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAASZJREFUWEdjZBhgwDjA9jMMvAOuS7OrMTL9m8nAxDhH4+GvpbAQuSnDKf2f6W8ew///ZrQKpb/MDIWMN2RZXzEwMoqCLPnPxKSo+eDHAxD7pixr1n9Gxqm0shxq7gPGG3JsSxgYGKIZ/jPc4v7/y0D2CcN3iAPYIv4zMiynsQM2g9PAdTm2BhYGhlWqj35dQ7bwpjy757///81p5QjNR78aBj4R0sp3xJo7GgKjITDwIQDL64z/Gc9pPP65CZZ6r8uwODAzMev+ZfgvTGyKJlndf8ZjjDfl2K78Z2DQBmnm/veLC1YSXpdlTWBkZJxPsqGkaTg7CBwALW4HLApICzHqqx74XEB9P5Fm4mgIjIbAwDfJBrxROuDN8gHvmJBWbFBf9Wg2BADolI2Z1SlUvwAAAABJRU5ErkJggg==";
const _imports_1$1 = "" + globalThis.__buildAssetsURL("unaction.5f27c21f.svg");
const _imports_2 = "" + globalThis.__buildAssetsURL("all.76c4c2ef.svg");
const _imports_4 = "" + globalThis.__buildAssetsURL("github.1a3306c4.svg");
const _imports_5 = "" + globalThis.__buildAssetsURL("home.65b5f818.svg");
const _sfc_main$1 = {
  __name: "Modal",
  __ssrInlineRender: true,
  setup(__props) {
    const visible = ref(false);
    useRouter();
    watch(
      visible,
      (newValue, oldValue) => {
        if (newValue) {
          document.body.style.overflowY = "hidden";
        } else {
          document.body.style.overflowY = "auto";
        }
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-3685d19e><div class="absolute top-18 right-10 z-260" data-v-3685d19e><img${ssrRenderAttr("src", _imports_0)} class="bg-white w-7 h-7 p-1 rounded-1 cursor-pointer" style="${ssrRenderStyle(!unref(visible) ? null : { display: "none" })}" data-v-3685d19e><img${ssrRenderAttr("src", _imports_1$1)} class="bg-white w-7 h-7 p-1 rounded-1 cursor-pointer" style="${ssrRenderStyle(unref(visible) ? null : { display: "none" })}" data-v-3685d19e></div><div class="${ssrRenderClass([{ "h-100vh": unref(visible) }, "fixed top-0 w-100vw h-0 flex justify-center items-center overflow-hidden z-250 transition-height duration-300 ease-in-out"])}" data-v-3685d19e><div class="w-full h-full p-8 flex justify-center items-center gap-20" style="${ssrRenderStyle({ "background-color": "#efeeee" })}" data-v-3685d19e><div class="img" data-v-3685d19e><img${ssrRenderAttr("src", _imports_2)} data-v-3685d19e></div><div class="img" data-v-3685d19e><img${ssrRenderAttr("src", _imports_1$2)} data-v-3685d19e></div><div class="img" data-v-3685d19e><img${ssrRenderAttr("src", _imports_4)} data-v-3685d19e></div><div class="img" data-v-3685d19e><img${ssrRenderAttr("src", _imports_5)} data-v-3685d19e></div></div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Modal.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-3685d19e"]]);
const _imports_1 = "" + globalThis.__buildAssetsURL("rocket.29767d6c.svg");
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useRouter();
    useHead({
      title: "Sakura"
    });
    const state = reactive({
      initData: {
        headContent: [],
        headTile: "",
        currentTime: "",
        bgImg: "",
        allPosts: [],
        nowPosts: []
      },
      isLoading: true
    });
    const indexState = useIndexState();
    const isLike = (postId) => {
      let likes = indexState.likePosts;
      return likes.includes(postId);
    };
    const loadMore = () => {
      let leng = state.initData.nowPosts.length;
      let newPosts = state.initData.allPosts.slice(leng, leng + 5);
      setTimeout(() => {
        state.initData.nowPosts.push(...newPosts);
      }, 1500);
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Loading = __nuxt_component_0;
      const _component_LoadMore = __nuxt_component_1;
      const _component_Actions = __nuxt_component_2;
      const _component_Modal = __nuxt_component_3;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "container flex-col items-center relative w-screen h-screen" }, _attrs))} data-v-593909d1>`);
      if (unref(state).isLoading) {
        _push(ssrRenderComponent(_component_Loading, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="w-screen h-screen relative" data-v-593909d1><div class="overflow-hidden" data-v-593909d1><div class="relative" data-v-593909d1><img${ssrRenderAttr("src", unref(state).initData.bgImg)} class="w-full h-screen" data-v-593909d1></div></div><div class="absolute top-10vh w-50 text-bg-primary z-200 px-10vw flex items-center justify-between" data-v-593909d1><div class="flex items-center justify-center w-30" data-v-593909d1><img${ssrRenderAttr("src", _imports_0$1)} class="w-20 h-10" data-v-593909d1><p class="" style="${ssrRenderStyle({ "font-size": "25px", "color": "white" })}" data-v-593909d1>Sakura</p></div></div><div class="absolute top-50vh left-15vw text-white w-50vw transform -translate-y-1/2" data-v-593909d1><div class="time" data-v-593909d1>${ssrInterpolate(unref(state).initData.currentTime)}</div><div class="content my-7 text-7 w-full" data-v-593909d1>${ssrInterpolate(unref(state).initData.headContent.hitokoto)}</div><div class="my-7 text-5" data-v-593909d1>\u2014\u2014${ssrInterpolate(unref(state).initData.headTile)}:${ssrInterpolate(unref(state).initData.headContent.from)}</div></div></div>`);
      if (unref(state).initData.nowPosts.length > 0) {
        _push(`<div class="${ssrRenderClass([unref(indexState).theme ? "dark-theme" : "light-theme", "content relative py-10 w-screen sm:px-1/10"])}" data-v-593909d1><div class="flex flex-col items-center w-full" data-v-593909d1><!--[-->`);
        ssrRenderList(unref(state).initData.nowPosts, (item) => {
          _push(`<div class="box w-full md:h-55vh lg:h-65vh my-7vh flex flex-col justify-center items-center border-1 rounded-2 border-gray-200 border-solid md:border-none md:even:flex-row-reverse md:flex-row" data-v-593909d1><div class="imgbox w-full h-full md:w-3/5" data-v-593909d1><img${ssrRenderAttr("src", item.imgs)} class="w-full h-full rounded-2 object-fill hover:brightness-120 cursor-pointer" data-v-593909d1></div><div class="textbox flex flex-col justify-center p-10 md:w-2/5 md:h-9/10 md:border-1 md:border-gray-200 md:border-solid rounded-2" data-v-593909d1><div class="time my-3 opacity-60 text-2" data-v-593909d1>${ssrInterpolate(item.createdAt.split("T")[0])}</div><div class="title my-3 text-6 cursor-pointer hover:underline" data-v-593909d1>${ssrInterpolate(item.title)}</div><div class="content mb-10 opacity-60" data-v-593909d1>${ssrInterpolate(item.sketch)}</div><div class="action opacity-60 flex items-center" data-v-593909d1><span class="iconfont icon-yanjing mx-1" data-v-593909d1></span><p class="mr-5" style="${ssrRenderStyle({ "font-size": "8px" })}" data-v-593909d1>${ssrInterpolate(item.views)}</p><span class="iconfont icon-xinxi mx-1" data-v-593909d1></span><p class="mr-5" style="${ssrRenderStyle({ "font-size": "8px" })}" data-v-593909d1>${ssrInterpolate(item.comments ? item.comments.length : 0)}</p>`);
          if (!isLike(item._id)) {
            _push(`<span class="iconfont icon-aixin" data-v-593909d1></span>`);
          } else {
            _push(`<!---->`);
          }
          if (isLike(item._id)) {
            _push(`<span class="iconfont icon-aixin1 text-red-500" data-v-593909d1></span>`);
          } else {
            _push(`<!---->`);
          }
          _push(`<p class="mr-5" style="${ssrRenderStyle({ "font-size": "8px" })}" data-v-593909d1>${ssrInterpolate(item.likes)}</p></div></div></div>`);
        });
        _push(`<!--]-->`);
        if (unref(state).initData.allPosts.length != unref(state).initData.nowPosts.length) {
          _push(`<div class="more" data-v-593909d1>`);
          _push(ssrRenderComponent(_component_LoadMore, { onClick: loadMore }, null, _parent));
          _push(`</div>`);
        } else {
          _push(`<div data-v-593909d1><p data-v-593909d1>\u5DF2\u7ECF\u52A0\u8F7D\u5168\u90E8\u4E86\u54E6\u3002</p></div>`);
        }
        _push(`</div><div class="midLine" data-v-593909d1></div></div>`);
      } else {
        _push(`<div class="py-30vh text-center" data-v-593909d1>\u4E3B\u4EBA\u592A\u61D2\u4E86\uFF0C\u8FD8\u6CA1\u53D1\u8868\u4EFB\u4F55\u6587\u7AE0\uFF01\uFF01</div>`);
      }
      _push(ssrRenderComponent(_component_Actions, null, null, _parent));
      _push(ssrRenderComponent(_component_Modal, null, null, _parent));
      _push(`<div id="rocket" class="z-100 pointer-events-none" data-v-593909d1><img${ssrRenderAttr("src", _imports_1)} class="w-full h-full" style="${ssrRenderStyle({ "pointer-events": "none" })}" data-v-593909d1></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-593909d1"]]);

export { index as default };
//# sourceMappingURL=index.6a3b7a71.mjs.map
