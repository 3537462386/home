import { d as defineStore } from './server.mjs';

const useIndexState = defineStore("index", {
  state: () => {
    return {
      theme: false,
      isMobile: false,
      likePosts: []
    };
  },
  actions: {
    changeTheme() {
      this.theme = !this.theme;
    },
    ToMobile() {
      this.isMobile = !this.isMobile;
    },
    setLikePost(likes) {
      this.likePosts = likes;
    }
  },
  persist: false
});

export { useIndexState as u };
//# sourceMappingURL=indexState.373c6501.mjs.map
