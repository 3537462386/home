globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import 'node-fetch-native/polyfill';
import { Server as Server$1 } from 'http';
import { Server } from 'https';
import destr from 'destr';
import { eventHandler, setHeaders, sendRedirect, defineEventHandler, handleCacheHeaders, createEvent, getRequestHeader, getRequestHeaders, setResponseHeader, createError, createApp, createRouter as createRouter$1, lazyEventHandler, toNodeListener } from 'h3';
import { createFetch as createFetch$1, Headers } from 'ofetch';
import { createCall, createFetch } from 'unenv/runtime/fetch/index';
import { createHooks } from 'hookable';
import { snakeCase } from 'scule';
import { hash } from 'ohash';
import { parseURL, withQuery, joinURL, withLeadingSlash, withoutTrailingSlash } from 'ufo';
import { createStorage } from 'unstorage';
import defu from 'defu';
import { toRouteMatcher, createRouter } from 'radix3';
import { promises } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'pathe';

const _runtimeConfig = {"app":{"baseURL":"/","buildAssetsDir":"/_nuxt/","cdnURL":""},"nitro":{"routeRules":{"/__nuxt_error":{"cache":false}},"envPrefix":"NUXT_"},"public":{"persistedState":{"storage":"cookies","debug":false,"cookieOptions":{}}}};
const ENV_PREFIX = "NITRO_";
const ENV_PREFIX_ALT = _runtimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_";
const getEnv = (key) => {
  const envKey = snakeCase(key).toUpperCase();
  return destr(process.env[ENV_PREFIX + envKey] ?? process.env[ENV_PREFIX_ALT + envKey]);
};
function isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function overrideConfig(obj, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey);
    if (isObject(obj[key])) {
      if (isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
      }
      overrideConfig(obj[key], subKey);
    } else {
      obj[key] = envValue ?? obj[key];
    }
  }
}
overrideConfig(_runtimeConfig);
const config$1 = deepFreeze(_runtimeConfig);
const useRuntimeConfig = () => config$1;
function deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      deepFreeze(value);
    }
  }
  return Object.freeze(object);
}

const globalTiming = globalThis.__timing__ || {
  start: () => 0,
  end: () => 0,
  metrics: []
};
const timingMiddleware = eventHandler((event) => {
  const start = globalTiming.start();
  const _end = event.res.end;
  event.res.end = function(chunk, encoding, cb) {
    const metrics = [["Generate", globalTiming.end(start)], ...globalTiming.metrics];
    const serverTiming = metrics.map((m) => `-;dur=${m[1]};desc="${encodeURIComponent(m[0])}"`).join(", ");
    if (!event.res.headersSent) {
      event.res.setHeader("Server-Timing", serverTiming);
    }
    _end.call(event.res, chunk, encoding, cb);
    return this;
  }.bind(event.res);
});

const _assets = {

};

function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0].replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "");
}

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

const storage = createStorage({});

const useStorage = () => storage;

storage.mount('/assets', assets$1);

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(createRouter({ routes: config.nitro.routeRules }));
function createRouteRulesHandler() {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      return sendRedirect(event, routeRules.redirect.to, routeRules.redirect.statusCode);
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    const path = new URL(event.req.url, "http://localhost").pathname;
    event.context._nitro.routeRules = getRouteRulesForPath(path);
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

const defaultCacheOptions = {
  name: "_",
  base: "/cache",
  swr: true,
  maxAge: 1
};
function defineCachedFunction(fn, opts) {
  opts = { ...defaultCacheOptions, ...opts };
  const pending = {};
  const group = opts.group || "nitro";
  const name = opts.name || fn.name || "_";
  const integrity = hash([opts.integrity, fn, opts]);
  const validate = opts.validate || (() => true);
  async function get(key, resolver) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    const entry = await useStorage().getItem(cacheKey) || {};
    const ttl = (opts.maxAge ?? opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || !validate(entry);
    const _resolve = async () => {
      if (!pending[key]) {
        entry.value = void 0;
        entry.integrity = void 0;
        entry.mtime = void 0;
        entry.expires = void 0;
        pending[key] = Promise.resolve(resolver());
      }
      entry.value = await pending[key];
      entry.mtime = Date.now();
      entry.integrity = integrity;
      delete pending[key];
      if (validate(entry)) {
        useStorage().setItem(cacheKey, entry).catch((error) => console.error("[nitro] [cache]", error));
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (opts.swr && entry.value) {
      _resolvePromise.catch(console.error);
      return Promise.resolve(entry);
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const key = (opts.getKey || getKey)(...args);
    const entry = await get(key, () => fn(...args));
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
const cachedFunction = defineCachedFunction;
function getKey(...args) {
  return args.length ? hash(args, {}) : "";
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions) {
  const _opts = {
    ...opts,
    getKey: (event) => {
      const url = event.req.originalUrl || event.req.url;
      const friendlyName = decodeURI(parseURL(url).pathname).replace(/[^a-zA-Z0-9]/g, "").substring(0, 16);
      const urlHash = hash(url);
      return `${friendlyName}.${urlHash}`;
    },
    validate: (entry) => {
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: [
      opts.integrity,
      handler
    ]
  };
  const _cachedHandler = cachedFunction(async (incomingEvent) => {
    const reqProxy = cloneWithProxy(incomingEvent.req, { headers: {} });
    const resHeaders = {};
    let _resSendBody;
    const resProxy = cloneWithProxy(incomingEvent.res, {
      statusCode: 200,
      getHeader(name) {
        return resHeaders[name];
      },
      setHeader(name, value) {
        resHeaders[name] = value;
        return this;
      },
      getHeaderNames() {
        return Object.keys(resHeaders);
      },
      hasHeader(name) {
        return name in resHeaders;
      },
      removeHeader(name) {
        delete resHeaders[name];
      },
      getHeaders() {
        return resHeaders;
      },
      end(chunk, arg2, arg3) {
        if (typeof chunk === "string") {
          _resSendBody = chunk;
        }
        if (typeof arg2 === "function") {
          arg2();
        }
        if (typeof arg3 === "function") {
          arg3();
        }
        return this;
      },
      write(chunk, arg2, arg3) {
        if (typeof chunk === "string") {
          _resSendBody = chunk;
        }
        if (typeof arg2 === "function") {
          arg2();
        }
        if (typeof arg3 === "function") {
          arg3();
        }
        return this;
      },
      writeHead(statusCode, headers2) {
        this.statusCode = statusCode;
        if (headers2) {
          for (const header in headers2) {
            this.setHeader(header, headers2[header]);
          }
        }
        return this;
      }
    });
    const event = createEvent(reqProxy, resProxy);
    event.context = incomingEvent.context;
    const body = await handler(event) || _resSendBody;
    const headers = event.res.getHeaders();
    headers.etag = headers.Etag || headers.etag || `W/"${hash(body)}"`;
    headers["last-modified"] = headers["Last-Modified"] || headers["last-modified"] || new Date().toUTCString();
    const cacheControl = [];
    if (opts.swr) {
      if (opts.maxAge) {
        cacheControl.push(`s-maxage=${opts.maxAge}`);
      }
      if (opts.staleMaxAge) {
        cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
      } else {
        cacheControl.push("stale-while-revalidate");
      }
    } else if (opts.maxAge) {
      cacheControl.push(`max-age=${opts.maxAge}`);
    }
    if (cacheControl.length) {
      headers["cache-control"] = cacheControl.join(", ");
    }
    const cacheEntry = {
      code: event.res.statusCode,
      headers,
      body
    };
    return cacheEntry;
  }, _opts);
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(event);
    if (event.res.headersSent || event.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.res.statusCode = response.code;
    for (const name in response.headers) {
      event.res.setHeader(name, response.headers[name]);
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

const plugins = [
  
];

function hasReqHeader(event, name, includes) {
  const value = getRequestHeader(event, name);
  return value && typeof value === "string" && value.toLowerCase().includes(includes);
}
function isJsonRequest(event) {
  return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || event.req.url?.endsWith(".json") || event.req.url?.includes("/api/");
}
function normalizeError(error) {
  const cwd = process.cwd();
  const stack = (error.stack || "").split("\n").splice(1).filter((line) => line.includes("at ")).map((line) => {
    const text = line.replace(cwd + "/", "./").replace("webpack:/", "").replace("file://", "").trim();
    return {
      text,
      internal: line.includes("node_modules") && !line.includes(".cache") || line.includes("internal") || line.includes("new Promise")
    };
  });
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage ?? (statusCode === 404 ? "Not Found" : "");
  const message = error.message || error.toString();
  return {
    stack,
    statusCode,
    statusMessage,
    message
  };
}

const errorHandler = (async function errorhandler(error, event) {
  const { stack, statusCode, statusMessage, message } = normalizeError(error);
  const errorObject = {
    url: event.node.req.url,
    statusCode,
    statusMessage,
    message,
    stack: "",
    data: error.data
  };
  event.node.res.statusCode = errorObject.statusCode !== 200 && errorObject.statusCode || 500;
  if (errorObject.statusMessage) {
    event.node.res.statusMessage = errorObject.statusMessage;
  }
  if (error.unhandled || error.fatal) {
    const tags = [
      "[nuxt]",
      "[request error]",
      error.unhandled && "[unhandled]",
      error.fatal && "[fatal]",
      Number(errorObject.statusCode) !== 200 && `[${errorObject.statusCode}]`
    ].filter(Boolean).join(" ");
    console.error(tags, errorObject.message + "\n" + stack.map((l) => "  " + l.text).join("  \n"));
  }
  if (isJsonRequest(event)) {
    event.node.res.setHeader("Content-Type", "application/json");
    event.node.res.end(JSON.stringify(errorObject));
    return;
  }
  const isErrorPage = event.node.req.url?.startsWith("/__nuxt_error");
  const res = !isErrorPage ? await useNitroApp().localFetch(withQuery(joinURL(useRuntimeConfig().app.baseURL, "/__nuxt_error"), errorObject), {
    headers: getRequestHeaders(event),
    redirect: "manual"
  }).catch(() => null) : null;
  if (!res) {
    const { template } = await import('./error-500.mjs');
    event.node.res.setHeader("Content-Type", "text/html;charset=UTF-8");
    event.node.res.end(template(errorObject));
    return;
  }
  for (const [header, value] of res.headers.entries()) {
    setResponseHeader(event, header, value);
  }
  if (res.status && res.status !== 200) {
    event.node.res.statusCode = res.status;
  }
  if (res.statusText) {
    event.node.res.statusMessage = res.statusText;
  }
  event.node.res.end(await res.text());
});

const assets = {
  "/_nuxt/1.0d299c40.jpg": {
    "type": "image/jpeg",
    "etag": "\"1555c5-FU6KuJk3/0q5rKeMwQ8OVVHQe+s\"",
    "mtime": "2023-10-08T07:52:49.356Z",
    "size": 1398213,
    "path": "../public/_nuxt/1.0d299c40.jpg"
  },
  "/_nuxt/1.b321b724.jpg": {
    "type": "image/jpeg",
    "etag": "\"248fd-lYPS5In4RdaZaxePPkjE0+nQlx0\"",
    "mtime": "2023-10-08T07:52:49.355Z",
    "size": 149757,
    "path": "../public/_nuxt/1.b321b724.jpg"
  },
  "/_nuxt/2.2fb2d4dd.jpg": {
    "type": "image/jpeg",
    "etag": "\"d187f-ZnLIAzsnhKwP5Are7cza1rpgR/0\"",
    "mtime": "2023-10-08T07:52:49.356Z",
    "size": 858239,
    "path": "../public/_nuxt/2.2fb2d4dd.jpg"
  },
  "/_nuxt/2.e01a1bdb.jpg": {
    "type": "image/jpeg",
    "etag": "\"23033-K2OPItKd9X2MWHPHsFVriGZBmY8\"",
    "mtime": "2023-10-08T07:52:49.355Z",
    "size": 143411,
    "path": "../public/_nuxt/2.e01a1bdb.jpg"
  },
  "/_nuxt/3.17d4bc3b.jpg": {
    "type": "image/jpeg",
    "etag": "\"1c5b7-/WYw8OoUQ8ZYUZeiciKp1oTkH/Y\"",
    "mtime": "2023-10-08T07:52:49.355Z",
    "size": 116151,
    "path": "../public/_nuxt/3.17d4bc3b.jpg"
  },
  "/_nuxt/3.342e13fb.jpg": {
    "type": "image/jpeg",
    "etag": "\"3d91d0-X5/jgtfkKx9erTe5gUYKPwp0O6U\"",
    "mtime": "2023-10-08T07:52:49.365Z",
    "size": 4035024,
    "path": "../public/_nuxt/3.342e13fb.jpg"
  },
  "/_nuxt/4.60c82fbf.jpg": {
    "type": "image/jpeg",
    "etag": "\"148cb2-d7703n/dMEhtUPVPqSMaJe2HvDw\"",
    "mtime": "2023-10-08T07:52:49.356Z",
    "size": 1346738,
    "path": "../public/_nuxt/4.60c82fbf.jpg"
  },
  "/_nuxt/4.c53feae0.jpg": {
    "type": "image/jpeg",
    "etag": "\"15ca8-CJr4yYiumw482uFeid5+UjECE5g\"",
    "mtime": "2023-10-08T07:52:49.355Z",
    "size": 89256,
    "path": "../public/_nuxt/4.c53feae0.jpg"
  },
  "/_nuxt/5.4d1801b1.jpg": {
    "type": "image/jpeg",
    "etag": "\"2076d-G54Rk5ylw3XEvLU2MvFA6xjj6fQ\"",
    "mtime": "2023-10-08T07:52:49.355Z",
    "size": 132973,
    "path": "../public/_nuxt/5.4d1801b1.jpg"
  },
  "/_nuxt/5.ac038416.jpg": {
    "type": "image/jpeg",
    "etag": "\"c0393-2uZRn89N4D7kg18PutNRtrn6YLU\"",
    "mtime": "2023-10-08T07:52:49.356Z",
    "size": 787347,
    "path": "../public/_nuxt/5.ac038416.jpg"
  },
  "/_nuxt/about.3e79d65e.js": {
    "type": "application/javascript",
    "etag": "\"8c-Fq6/GSj9qc/+9L/ozEs0AlHtNbM\"",
    "mtime": "2023-10-08T07:52:49.363Z",
    "size": 140,
    "path": "../public/_nuxt/about.3e79d65e.js"
  },
  "/_nuxt/about.7ddadf0f.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"d7-H//XDbesWuZ9TykvkyZqDJiNbVI\"",
    "mtime": "2023-10-08T07:52:49.364Z",
    "size": 215,
    "path": "../public/_nuxt/about.7ddadf0f.css"
  },
  "/_nuxt/about.c9799bbd.svg": {
    "type": "image/svg+xml",
    "etag": "\"499-z0AaRWzh9+XL+SNeAY2U9DlMyEg\"",
    "mtime": "2023-10-08T07:52:49.354Z",
    "size": 1177,
    "path": "../public/_nuxt/about.c9799bbd.svg"
  },
  "/_nuxt/about.f8cf210b.js": {
    "type": "application/javascript",
    "etag": "\"f1c-JXjjkChk/MYRqnQB/rnmdt+QeUk\"",
    "mtime": "2023-10-08T07:52:49.363Z",
    "size": 3868,
    "path": "../public/_nuxt/about.f8cf210b.js"
  },
  "/_nuxt/Actions.0c94f109.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"124-lpNzVEuYwDgR/YRz/Q3VINtzeiE\"",
    "mtime": "2023-10-08T07:52:49.365Z",
    "size": 292,
    "path": "../public/_nuxt/Actions.0c94f109.css"
  },
  "/_nuxt/addSong.fdd86721.js": {
    "type": "application/javascript",
    "etag": "\"5e5-DzNwrZCQUSUTARhJedaN830/byw\"",
    "mtime": "2023-10-08T07:52:49.364Z",
    "size": 1509,
    "path": "../public/_nuxt/addSong.fdd86721.js"
  },
  "/_nuxt/all.76c4c2ef.svg": {
    "type": "image/svg+xml",
    "etag": "\"355-NvJv5QuAXAL1kd5GbnkJ9ldpT0E\"",
    "mtime": "2023-10-08T07:52:49.355Z",
    "size": 853,
    "path": "../public/_nuxt/all.76c4c2ef.svg"
  },
  "/_nuxt/base.0750e8f8.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1ed7-1PmonwTpLGeJwaM75e/fDU4WkUY\"",
    "mtime": "2023-10-08T07:52:49.366Z",
    "size": 7895,
    "path": "../public/_nuxt/base.0750e8f8.css"
  },
  "/_nuxt/base.38812cfa.js": {
    "type": "application/javascript",
    "etag": "\"a43-YnW0/gRQsF10SRcI8UFCUGnGKnI\"",
    "mtime": "2023-10-08T07:52:49.364Z",
    "size": 2627,
    "path": "../public/_nuxt/base.38812cfa.js"
  },
  "/_nuxt/composables.cea79c3c.js": {
    "type": "application/javascript",
    "etag": "\"5c-Du3rP7q01AC6YgLmGmy09bqDDUI\"",
    "mtime": "2023-10-08T07:52:49.364Z",
    "size": 92,
    "path": "../public/_nuxt/composables.cea79c3c.js"
  },
  "/_nuxt/create.e9191465.js": {
    "type": "application/javascript",
    "etag": "\"756-YNtR86LIK+tO/TsyLHkIgaWAz2w\"",
    "mtime": "2023-10-08T07:52:49.364Z",
    "size": 1878,
    "path": "../public/_nuxt/create.e9191465.js"
  },
  "/_nuxt/entry.65810f75.js": {
    "type": "application/javascript",
    "etag": "\"1231a6-5RB/zEaNat7E5kIn9Wem3SdY23U\"",
    "mtime": "2023-10-08T07:52:49.364Z",
    "size": 1192358,
    "path": "../public/_nuxt/entry.65810f75.js"
  },
  "/_nuxt/entry.9c6b3034.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"4b9c-dpTAk+nl69qBA9ikldqONP71qRI\"",
    "mtime": "2023-10-08T07:52:49.366Z",
    "size": 19356,
    "path": "../public/_nuxt/entry.9c6b3034.css"
  },
  "/_nuxt/error-404.5035f0f2.js": {
    "type": "application/javascript",
    "etag": "\"8d0-I9C2BP0oOdnacufuECKGN9Q1ono\"",
    "mtime": "2023-10-08T07:52:49.364Z",
    "size": 2256,
    "path": "../public/_nuxt/error-404.5035f0f2.js"
  },
  "/_nuxt/error-404.a6f724cc.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"e2e-7OzjFJovqwNIX/fq/cgkg/UMQXU\"",
    "mtime": "2023-10-08T07:52:49.366Z",
    "size": 3630,
    "path": "../public/_nuxt/error-404.a6f724cc.css"
  },
  "/_nuxt/error-500.24c1dd0a.js": {
    "type": "application/javascript",
    "etag": "\"778-mQvurPOeyZFUsxC8ZBGNc1IHHqM\"",
    "mtime": "2023-10-08T07:52:49.364Z",
    "size": 1912,
    "path": "../public/_nuxt/error-500.24c1dd0a.js"
  },
  "/_nuxt/error-500.d92554dd.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"79e-xML352/WFfAxkR9h+VWMQhHAJ5Y\"",
    "mtime": "2023-10-08T07:52:49.365Z",
    "size": 1950,
    "path": "../public/_nuxt/error-500.d92554dd.css"
  },
  "/_nuxt/error-component.a273e46f.js": {
    "type": "application/javascript",
    "etag": "\"4ad-gxgKXhdcRWj2Z5bU7L1WiG3njgM\"",
    "mtime": "2023-10-08T07:52:49.363Z",
    "size": 1197,
    "path": "../public/_nuxt/error-component.a273e46f.js"
  },
  "/_nuxt/github.1a3306c4.svg": {
    "type": "image/svg+xml",
    "etag": "\"546-unTC7sFvxV+JnC0ctWcJPo6K9U8\"",
    "mtime": "2023-10-08T07:52:49.355Z",
    "size": 1350,
    "path": "../public/_nuxt/github.1a3306c4.svg"
  },
  "/_nuxt/home.65b5f818.svg": {
    "type": "image/svg+xml",
    "etag": "\"364-MvXlbLL9Wf/+VXAtIwDyJAJN0k8\"",
    "mtime": "2023-10-08T07:52:49.355Z",
    "size": 868,
    "path": "../public/_nuxt/home.65b5f818.svg"
  },
  "/_nuxt/iconfont.2ccf6fbb.woff": {
    "type": "font/woff",
    "etag": "\"1078-T6Cgs4VCSH8138STsq6HESslars\"",
    "mtime": "2023-10-08T07:52:49.353Z",
    "size": 4216,
    "path": "../public/_nuxt/iconfont.2ccf6fbb.woff"
  },
  "/_nuxt/iconfont.f54e1942.ttf": {
    "type": "font/ttf",
    "etag": "\"18ac-+EXcoY31G/viPk+rYdHVd3XjDko\"",
    "mtime": "2023-10-08T07:52:49.354Z",
    "size": 6316,
    "path": "../public/_nuxt/iconfont.f54e1942.ttf"
  },
  "/_nuxt/index.114356d6.js": {
    "type": "application/javascript",
    "etag": "\"2713-Lam3zzTKmx3nuQmiITW+9Kzi6pI\"",
    "mtime": "2023-10-08T07:52:49.364Z",
    "size": 10003,
    "path": "../public/_nuxt/index.114356d6.js"
  },
  "/_nuxt/index.403a4c53.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"b93-ZdwFHB/Dln+eUaFhMkSCzb8vezY\"",
    "mtime": "2023-10-08T07:52:49.366Z",
    "size": 2963,
    "path": "../public/_nuxt/index.403a4c53.css"
  },
  "/_nuxt/index.48fd2eb0.js": {
    "type": "application/javascript",
    "etag": "\"701a-u0l/IQoamfe/aeiAmROPYgIbBnU\"",
    "mtime": "2023-10-08T07:52:49.364Z",
    "size": 28698,
    "path": "../public/_nuxt/index.48fd2eb0.js"
  },
  "/_nuxt/index.57d7da95.js": {
    "type": "application/javascript",
    "etag": "\"3028-3P4bsIYC1nzwNwW0OxwtSnOk8A4\"",
    "mtime": "2023-10-08T07:52:49.364Z",
    "size": 12328,
    "path": "../public/_nuxt/index.57d7da95.js"
  },
  "/_nuxt/index.78f21062.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"de7-T5KtOAKqg0/XrcIQUp0rjjb2l68\"",
    "mtime": "2023-10-08T07:52:49.365Z",
    "size": 3559,
    "path": "../public/_nuxt/index.78f21062.css"
  },
  "/_nuxt/index.88908362.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"438c-FGa36qcTyab1wsZj0ZF3n2tBTt4\"",
    "mtime": "2023-10-08T07:52:49.366Z",
    "size": 17292,
    "path": "../public/_nuxt/index.88908362.css"
  },
  "/_nuxt/index.b9fe2899.js": {
    "type": "application/javascript",
    "etag": "\"1268-5lm+IQH01Ho46flx64/da1iF2ls\"",
    "mtime": "2023-10-08T07:52:49.364Z",
    "size": 4712,
    "path": "../public/_nuxt/index.b9fe2899.js"
  },
  "/_nuxt/indexState.c13635ac.js": {
    "type": "application/javascript",
    "etag": "\"116-YnXgSP5gLt4R7v8Wnd6BS79fmQM\"",
    "mtime": "2023-10-08T07:52:49.364Z",
    "size": 278,
    "path": "../public/_nuxt/indexState.c13635ac.js"
  },
  "/_nuxt/logo.43113877.svg": {
    "type": "image/svg+xml",
    "etag": "\"f54-ZAYHRNye9ZVpe/AaODumpwSK3H8\"",
    "mtime": "2023-10-08T07:52:49.354Z",
    "size": 3924,
    "path": "../public/_nuxt/logo.43113877.svg"
  },
  "/_nuxt/me.02f49700.jpg": {
    "type": "image/jpeg",
    "etag": "\"20109-AumNwh7TyOoB4GCSZ9VYPthNF1M\"",
    "mtime": "2023-10-08T07:52:49.354Z",
    "size": 131337,
    "path": "../public/_nuxt/me.02f49700.jpg"
  },
  "/_nuxt/rocket.29767d6c.svg": {
    "type": "image/svg+xml",
    "etag": "\"4214-dUZrdY7ns0PAaI8ALMHX808Olp8\"",
    "mtime": "2023-10-08T07:52:49.355Z",
    "size": 16916,
    "path": "../public/_nuxt/rocket.29767d6c.svg"
  },
  "/_nuxt/unaction.5f27c21f.svg": {
    "type": "image/svg+xml",
    "etag": "\"260-V5v3a50RPsCOMfHbvf6VU9SrpK0\"",
    "mtime": "2023-10-08T07:52:49.355Z",
    "size": 608,
    "path": "../public/_nuxt/unaction.5f27c21f.svg"
  }
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises.readFile(resolve(serverDir, assets[id].path))
}

const publicAssetBases = [];

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base of publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = ["HEAD", "GET"];
const EncodingMap = { gzip: ".gz", br: ".br" };
const _f4b49z = eventHandler((event) => {
  if (event.req.method && !METHODS.includes(event.req.method)) {
    return;
  }
  let id = decodeURIComponent(withLeadingSlash(withoutTrailingSlash(parseURL(event.req.url).pathname)));
  let asset;
  const encodingHeader = String(event.req.headers["accept-encoding"] || "");
  const encodings = encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort().concat([""]);
  if (encodings.length > 1) {
    event.res.setHeader("Vary", "Accept-Encoding");
  }
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      throw createError({
        statusMessage: "Cannot find static asset " + id,
        statusCode: 404
      });
    }
    return;
  }
  const ifNotMatch = event.req.headers["if-none-match"] === asset.etag;
  if (ifNotMatch) {
    event.res.statusCode = 304;
    event.res.end();
    return;
  }
  const ifModifiedSinceH = event.req.headers["if-modified-since"];
  if (ifModifiedSinceH && asset.mtime) {
    if (new Date(ifModifiedSinceH) >= new Date(asset.mtime)) {
      event.res.statusCode = 304;
      event.res.end();
      return;
    }
  }
  if (asset.type && !event.res.getHeader("Content-Type")) {
    event.res.setHeader("Content-Type", asset.type);
  }
  if (asset.etag && !event.res.getHeader("ETag")) {
    event.res.setHeader("ETag", asset.etag);
  }
  if (asset.mtime && !event.res.getHeader("Last-Modified")) {
    event.res.setHeader("Last-Modified", asset.mtime);
  }
  if (asset.encoding && !event.res.getHeader("Content-Encoding")) {
    event.res.setHeader("Content-Encoding", asset.encoding);
  }
  if (asset.size && !event.res.getHeader("Content-Length")) {
    event.res.setHeader("Content-Length", asset.size);
  }
  return readAsset(id);
});

const _lazy_UppXhS = () => import('./renderer.mjs');

const handlers = [
  { route: '', handler: _f4b49z, lazy: false, middleware: true, method: undefined },
  { route: '/__nuxt_error', handler: _lazy_UppXhS, lazy: true, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_UppXhS, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const h3App = createApp({
    debug: destr(false),
    onError: errorHandler
  });
  h3App.use(config.app.baseURL, timingMiddleware);
  const router = createRouter$1();
  h3App.use(createRouteRulesHandler());
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(/\/+/g, "/");
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(h.route.replace(/:\w+|\*\*/g, "_"));
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router);
  const localCall = createCall(toNodeListener(h3App));
  const localFetch = createFetch(localCall, globalThis.fetch);
  const $fetch = createFetch$1({ fetch: localFetch, Headers, defaults: { baseURL: config.app.baseURL } });
  globalThis.$fetch = $fetch;
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch
  };
  for (const plugin of plugins) {
    plugin(app);
  }
  return app;
}
const nitroApp = createNitroApp();
const useNitroApp = () => nitroApp;

const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const server = cert && key ? new Server({ key, cert }, toNodeListener(nitroApp.h3App)) : new Server$1(toNodeListener(nitroApp.h3App));
const port = destr(process.env.NITRO_PORT || process.env.PORT) || 3e3;
const host = process.env.NITRO_HOST || process.env.HOST;
const s = server.listen(port, host, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  const protocol = cert && key ? "https" : "http";
  const i = s.address();
  const baseURL = (useRuntimeConfig().app.baseURL || "").replace(/\/$/, "");
  const url = `${protocol}://${i.family === "IPv6" ? `[${i.address}]` : i.address}:${i.port}${baseURL}`;
  console.log(`Listening ${url}`);
});
{
  process.on("unhandledRejection", (err) => console.error("[nitro] [dev] [unhandledRejection] " + err));
  process.on("uncaughtException", (err) => console.error("[nitro] [dev] [uncaughtException] " + err));
}
const nodeServer = {};

export { useRuntimeConfig as a, getRouteRules as g, nodeServer as n, useNitroApp as u };
//# sourceMappingURL=node-server.mjs.map
