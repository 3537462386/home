const interopDefault = r => r.default || r || [];
const styles = {
  "../virtual:nuxt:C:/Users/lw/Desktop/workspace/home/MyBlog/vite-nuxt3-app/.nuxt/unocss.mjs": () => import('./unocss-styles.de9d2366.mjs').then(interopDefault),
  "pages/about.vue": () => import('./about-styles.eb28cf2f.mjs').then(interopDefault),
  "pages/addSong.vue": () => import('./addSong-styles.914d8874.mjs').then(interopDefault),
  "pages/posts/[id]/index.vue": () => import('./index-styles.faca09a3.mjs').then(interopDefault),
  "pages/index.vue": () => import('./index-styles.7cbccfa3.mjs').then(interopDefault),
  "pages/posts/create.vue": () => import('./create-styles.7d0e994f.mjs').then(interopDefault),
  "pages/posts/index.vue": () => import('./index-styles.1d7809bc.mjs').then(interopDefault),
  "components/Head.vue": () => import('./Head-styles.62a41a6a.mjs').then(interopDefault),
  "components/Loading.vue": () => import('./Loading-styles.e8fdaa78.mjs').then(interopDefault),
  "components/Modal.vue": () => import('./Modal-styles.7464d906.mjs').then(interopDefault),
  "components/LoadMore.vue": () => import('./LoadMore-styles.b224527a.mjs').then(interopDefault),
  "../node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./error-404-styles.f99becea.mjs').then(interopDefault),
  "../node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./error-500-styles.a88118cd.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
