const __uno = "#--unocss--{layer:__ALL__}";

const unocssStyles_de9d2366 = [__uno];

export { unocssStyles_de9d2366 as default };
//# sourceMappingURL=unocss-styles.de9d2366.mjs.map
